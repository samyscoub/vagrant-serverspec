Ansible role: Canopsis-influxdb-client
======================================

Configure Canopsis in order to interact with InfluxDB database.

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_idbc_host", "localhost", "The default host in which InfluxDB will be installed"
   "cps_idbc_port", "4444", "The UDP default port in which InfluxDB service will listen"
   "cps_idbc_database", "canopsis", "The default Canopsis database name"
   "cps_idbc_user", "cpsinflux", "The default InfluxDB username"
   "cps_idbc_password", "canopsis", "The default InfluxDB password"

Example
-------

None.
