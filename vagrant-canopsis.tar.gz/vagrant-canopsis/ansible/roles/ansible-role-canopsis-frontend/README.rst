Ansible role: Canopsis-frontend
===============================

Git clone the Canopsis webcore sources and install UI bricks.

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-backend

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_frontend_git", "https://git.canopsis.net/canopsis/canopsis-webcore.git", "Canopsis webcore repository, if 'none', the role will use the sources in cps_frontend_src"
   "cps_frontend_src", "/home/user/devel/projects/canopsis-devkit/canopsis/webcore", "Path to Canopsis webcore sources"
   "cps_frontend_version", "develop", "current version of your webcore submodule"
   "cps_frontend_workdir", "repo/webcore", "location in the Canopsis environment where the webcore will be installed"
   "cps_frontend_webmodules", "The default list is in defaults/main.yml", "The list of UI bricks to install. If externals is true, it means that the brick is an external brick and has to be cloned before."

Example
-------

None.