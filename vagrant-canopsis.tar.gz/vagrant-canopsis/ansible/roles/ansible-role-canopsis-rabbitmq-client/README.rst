Ansible role: Canopsis-rabbitmq-client
======================================

Configure Canopsis in order to interact with RabbitMQ service.

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-backend

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_amqpc_rabbithost", "localhost", "The default host in which RabbitMQ will be installed"
   "cps_amqpc_rabbitport", "5672", "The default port in which RabbitMQ service will listen"
   "cps_amqpc_rabbitvhost", "canopsis", "RabbitMQ vhost"
   "cps_amqpc_rabbituser", "cpsrabbit", "Rabbit username"
   "cps_amqpc_rabbitpassword", "canopsis", "Rabbit user password"

Example
-------

None.
