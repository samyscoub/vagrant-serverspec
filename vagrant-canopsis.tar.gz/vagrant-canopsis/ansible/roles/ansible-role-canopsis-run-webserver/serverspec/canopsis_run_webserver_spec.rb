describe command('sudo su - canopsis -c "service webserver status"') do
    its(:stdout) { should_not contain('FATAL') }
    its(:stdout) { should_not contain('STOPPED') }
    its(:exit_status) { should eq 0 }
end
describe port(8082) do
  it { should be_listening }
end
