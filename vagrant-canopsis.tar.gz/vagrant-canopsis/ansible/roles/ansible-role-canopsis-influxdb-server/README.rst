Ansible role: Canopsis-influxdb-server
======================================

Configure the InfluxDB database.

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_idb_host", "localhost", "The default host in which InfluxDB will be installed"
   "cps_idb_port", "8086", "The default HTTP port in which InfluxDB service will listen"
   "cps_idb_udp_port", "4444", "The default UDP port in which InfluxDB service will listen"
   "cps_idb_adminpassword", "admin", "The default password for admin InfluxDB user"
   "cps_idb_database", "canopsis", "The default Canopsis database name"
   "cps_idb_user", "cpsinflux", "The default InfluxDB username"
   "cps_idb_password", "canopsis", "The default InfluxDB password"

Example
-------

None.
