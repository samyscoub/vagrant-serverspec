describe command('service influxdb status') do
    its(:stdout) { should_not contain('not running') }
    its(:stdout) { should_not contain('FAILED') }
    its(:exit_status) { should eq 0 }
end

def influxdb_version
  command("influx --version|awk '{print $NF}'").stdout
end

def required_influxdb_version?
  influxdb_version =~ /^(0\.|1\.[012]).*/
end

describe port(8083), :if => required_influxdb_version? do
  it { should be_listening }
end
describe port(8086) do
  it { should be_listening }
end
describe port(8088) do
  it { should be_listening }
end
describe port(4444) do
  it { should be_listening }
end
