describe command('kill -0 `cat /opt/canopsis/var/run/supervisord.pid`') do
    its(:stdout) { should_not contain('No such file or directory') }
    its(:exit_status) { should eq 0 }
end
