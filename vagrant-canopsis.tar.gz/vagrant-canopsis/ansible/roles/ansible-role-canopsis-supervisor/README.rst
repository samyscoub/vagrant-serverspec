Ansible role: Canopsis-supervisor
=================================

Deploy supervisord, configure it and launch amqp2engines and webserver services

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

None.

Example
-------

None.