Ansible role: Canopsis-collecd
==============================

Install Collectd

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_collectd_rabbithost", "localhost", "Host in which Rabbit is installed"
   "cps_collectd_rabbitport", "5672", "Rabbit listening port"
   "cps_collectd_rabbitvhost", "canopsis", "Rabbit vhost"
   "cps_collectd_rabbituser", "cpsrabbit", "Rabbit username"
   "cps_collectd_rabbitpassword", "canopsis", "Rabbit password"

Example
-------

None.