describe command('sudo su - canopsis -c "service collectd status"') do
    its(:stdout) { should_not contain('FATAL') }
    its(:stdout) { should_not contain('STOPPED') }
    its(:exit_status) { should eq 0 }
end
