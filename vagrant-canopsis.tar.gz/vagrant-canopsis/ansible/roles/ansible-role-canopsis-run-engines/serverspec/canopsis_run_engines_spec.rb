describe command('sudo su - canopsis -c "service amqp2engines status"') do
    its(:stdout) { should contain('RUNNING') }
    its(:stdout) { should_not contain('FATAL') }
    its(:stdout) { should_not contain('STOPPED') }
    its(:exit_status) { should eq 0 }
end
