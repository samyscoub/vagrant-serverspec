Ansible role: Canopsis-mongodb-client
=====================================

Configure Canopsis interact with MongoDB database.

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-backend

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_mdb_mongohost", "localhost", "The default host in which MongoDB will be installed"
   "cps_mdb_mongoport", "27017", "The default port in which MongoDB service will listen"
   "cps_mdb_mongodatabase", "canopsis", "The default Canopsis database name"
   "cps_mdb_mongouser", "cpsmongo", "The MongoDB username"
   "cps_mdb_mongopassword", "canopsis", "The MongoDB user password"

Example
-------

None.
