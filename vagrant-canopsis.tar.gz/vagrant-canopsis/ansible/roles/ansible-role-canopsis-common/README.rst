Ansible role: Canopsis-common
====================================

Create the Canopsis user and git clone 'Externals' repository.

Dependencies
------------

None

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "online", "true", "enable/disable online installation. Warning: actually not used"
   "cpsuser", "canopsis", "User name for Canopsis environment"
   "cpsgroup", "canopsis", "Group for Canopsis environment"
   "cpshome", "/opt/canopsis", "Canopsis user home directory"
   "cps_externals_git", "https://git.canopsis.net/canopsis/canopsis-externals.git", "Externals git repository URL, if 'none' the role will use the given directory in cps_externals_src variable"
   "cps_externals_src", "/home/user/devel/projects/canopsis-devkit/canopsis/externals", "path to externals sources"
   "cps_externals_version", "develop", "the version of your 'Externals' submodule"
   "cps_externals_workdir", "repo/common", "the location in the Canopsis environment in which the repository will be placed"

Example
-------

None