Ansible role: Canopsis-documentation
====================================

Build Canopsis documentation and put it on the right location.

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-backend
  - role: ansible-role-canopsis-frontend

Role variables
--------------

None

Example
-------

None