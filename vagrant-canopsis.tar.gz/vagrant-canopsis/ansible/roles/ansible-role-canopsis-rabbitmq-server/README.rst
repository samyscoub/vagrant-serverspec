Ansible role: Canopsis-rabbitmq-server
======================================

Configure the RabbitMQ service

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_amqp_rabbithost", "localhost", "The default host in which RabbitMQ will be installed"
   "cps_amqp_rabbitport", "5672", "The default port in which RabbitMQ service will listen"
   "cps_amqp_rabbitvhost", "canopsis", "RabbitMQ vhost"
   "cps_amqp_rabbituser", "cpsrabbit", "Rabbit username"
   "cps_amqp_rabbitpassword", "canopsis", "Rabbit user password"

Example
-------

None.
