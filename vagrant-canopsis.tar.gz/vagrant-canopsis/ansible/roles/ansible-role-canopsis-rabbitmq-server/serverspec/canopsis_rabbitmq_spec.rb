describe command('service rabbitmq-server status') do
    its(:stdout) { should_not contain('nodedown') }
    its(:exit_status) { should eq 0 }
end
describe port(5672) do
  it { should be_listening }
end
describe port(15672) do
  it { should be_listening }
end
