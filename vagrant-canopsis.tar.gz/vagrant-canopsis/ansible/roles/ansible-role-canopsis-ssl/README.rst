Ansible role: Canopsis-ssl
==========================

Create the server SSL certificate for Canopsis.

Dependencies
------------

  - role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_ssl_key_bits", "2048", "bits number to encrypt the ssl key"
   "cps_ssl_dir", "{{ cpshome }}/etc/ssl", "SSL certificate location"
   "cps_ssl_countryname", "FR", "Country in which the certificate is generated"
   "cps_ssl_state", "France", "State in which the certificate is generated"
   "cps_ssl_locality", "Wasquehal", "City in which the certificate is generated"
   "cps_ssl_organization", "Capensis", "Organization which generates the certificate"
   "cps_ssl_organizationalunit", "Canopsis", "Entity which generates the certificate"
   "cps_ssl_cname", "cpsnode", "CNAME of organization which generates the certificate"
   "cps_ssl_email", "contact@capensis.fr", "Email of the organizatiopn which generates the certificate"
   "cps_ssl_password", "cpsnode", "default password for the certificate"

Example
-------

None.
