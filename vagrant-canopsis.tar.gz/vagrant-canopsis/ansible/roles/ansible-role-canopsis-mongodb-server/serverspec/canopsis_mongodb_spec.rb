describe command('service mongod status') do
    its(:stdout) { should_not contain('FAIL') }
    its(:stdout) { should_not contain('not running') }
    its(:stdout) { should_not contain('failed!') }
    its(:exit_status) { should eq 0 }
end
describe port(27017) do
  it { should be_listening.with('tcp') }
end
