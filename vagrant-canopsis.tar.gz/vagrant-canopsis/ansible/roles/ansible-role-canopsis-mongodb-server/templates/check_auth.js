var conn = new Mongo();
var db = conn.getDB('admin');
var opts = db.runCommand({'getCmdLineOpts': 1});
if(opts.ok == 1) {
    if (!opts.parsed.security || !opts.parsed.security.authorization || opts.parsed.security.authorization === 'disabled') {
        quit(1);
    }
    else {
        quit(0);
    }
}
else if(opts.errmsg.indexOf('not auth') !== -1) {
    quit(0);
}
else {
    quit(1);
}
