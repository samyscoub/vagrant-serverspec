// Add common user
conn = new Mongo();
db = conn.getDB('admin');
db.auth('admin', '{{ cps_mdb_mongoadminpassword}}');

db = conn.getDB('{{ cps_mdb_mongodatabase }}');

if(db.getUser('{{ cps_mdb_mongouser }}') == null) {
    db.createUser(
        {
            'user': '{{ cps_mdb_mongouser }}',
            'pwd': '{{ cps_mdb_mongopassword }}',
            'roles': [
                {
                    'role': 'dbOwner',
                    'db': '{{ cps_mdb_mongodatabase }}'
                }
            ]
        }
    );
}
else {
    db.updateUser(
        '{{ cps_mdb_mongouser }}',
        {
            'pwd': '{{ cps_mdb_mongopassword }}',
            'roles': [
                {
                    'role': 'dbOwner',
                    'db': '{{ cps_mdb_mongodatabase }}'
                }
            ]
        }
    );
}
