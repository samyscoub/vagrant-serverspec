Ansible role: Canopsis-provisionning
====================================

Adapt Canopsis for the user by filling the databases with configurations.

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-backend
  - role: ansible-role-canopsis-mongodb-server
  - role: ansible-role-canopsis-influxdb-server

Role variables
--------------

None.

Example
-------

None.