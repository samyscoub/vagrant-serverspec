Ansible role: Canopsis-backend
==============================

Git clone the Canopsis/core sources and install all Python project with unit and functional tests

Dependencies
------------

- role: ansible-role-canopsis-common

Role variables
--------------

.. csv-table::
   :header: "Variable", "Default", "Description"

   "cps_backend_git", "https://git.canopsis.net/canopsis/canopsis.git", "Canopsis core git repository URL, if 'none' the role will use the given directory in cps_externals_src variable"
   "cps_backend_src", "/home/user/devel/projects/canopsis-devkit/canopsis/core", "Path to externals sources"
   "cps_backend_workdir", "repo/backend", "The location in the Canopsis environment in which the repository will be placed"
   "canolibs", "by default, the list is in default/main.yml", "List of Canopsis Python projects to install"

Example
-------

None.
