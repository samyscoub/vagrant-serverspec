#!/bin/bash

cd $HOME/var/lib/canopsis/unittest
ERROR=0

for unittest in `find $HOME/var/lib/canopsis/unittest -name "*.py" | grep -v __init__.py | xargs`
do
    echo -n " - $unittest ... "

    unittestname=${unittest#$HOME/var/lib/canopsis/unittest}
    LOGPATH=$HOME/var/log/unittest/${unittestname%.py}.log

    mkdir -p `dirname $LOGPATH`

    python $unittest > $LOGPATH 2>&1

    if [ $? -eq 0 ]
    then
        echo "OK"
    else
        echo "FAIL"
        ERROR=1
    fi
done

exit $ERROR
