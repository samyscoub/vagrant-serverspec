Ansible role: Canopsis-demo-provisionning
=========================================

Put some dashboards into CANOPSIS

Dependencies
------------

  - role: ansible-role-canopsis-common
  - role: ansible-role-canopsis-provisionning

Role variables
--------------

None.

Example
-------

None.