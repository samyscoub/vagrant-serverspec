window.Handlebars.registerHelper('progressbar', function(metric, state, options) {
            var html = "No metric available";
            if(state === 0) {
                html = '<div class="progress">';
                html += '<div class="progress-bar progress-bar-success" role="progressbar" style="width: ' + metric + '%">';
                html += metric + '% (success)';
                html += '</div>';
                html += '</div>';
            }
            if(state === 1) {
                html = '<div class="progress">';
                html += '<div class="progress-bar progress-bar-warning" role="progressbar" style="width: ' + metric + '%">';
                html += metric + '% (minor)';
                html += '</div>';
                html += '</div>';
            }
            if(state === 2) {
                html = '<div class="progress">';
                html += '<div class="progress-bar progress-bar-warning" role="progressbar" style="width: ' + metric + '%">';
                html += metric + '% (major)';
                html += '</div>';
                html += '</div>';
            }
            if(state === 3) {
                html = '<div class="progress">';
                html += '<div class="progress-bar progress-bar-danger" role="progressbar" style="width: ' + metric + '%">';
                html += metric + '% (critical)';
                html += '</div>';
                html += '</div>';
            }

            return html;
        });
