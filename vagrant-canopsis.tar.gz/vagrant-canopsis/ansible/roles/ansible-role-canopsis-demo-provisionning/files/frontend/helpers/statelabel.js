window.Handlebars.registerHelper('statelabel', function(state, options) {
            var html = "No state available";
            if(state === 0) {
                html = '<span class="label label-success">Ok</span>';
            }
            if(state === 1) {
                html = '<span class="label label-warning">Minor</span>';
            }
            if(state === 2) {
                html = '<span class="label label-warning">Major</span>';
            }
            if(state === 3) {
                html = '<span class="label label-danger">Critical</span>';
            }

            return html;
        });
