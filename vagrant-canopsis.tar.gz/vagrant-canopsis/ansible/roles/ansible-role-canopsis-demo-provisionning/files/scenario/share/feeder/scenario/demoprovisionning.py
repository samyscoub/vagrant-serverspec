# -*- coding: utf-8 -*-
# --------------------------------
# Copyright (c) 2014 "Capensis" [http://www.capensis.com]
#
# This file is part of Canopsis.
#
# Canopsis is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Canopsis is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with Canopsis.  If not, see <http://www.gnu.org/licenses/>.
# ---------------------------------

from canopsis.feeder.scenario_utils import event_builder
import random
import time
import datetime


class DemoProvisionning():

    def el1(self, **kwargs):
        return event_builder.check(
            state=0,
            component='Demo',
            resource='DemoRES1',
            **kwargs
        )

    def el2(self, **kwargs):
        return event_builder.check(
            state=1,
            component='Demo',
            resource='DemoRES2',
            **kwargs
        )

    def el3(self, **kwargs):
        rand1 = random.randint(0,200)
        rand2 = random.randint(0,200)
        rand3 = random.randint(0,200)
        randres = random.randint(0,200)
	datetodayobj = datetime.datetime.now()
        datetoday = datetodayobj.strftime('%Y-%m-%d %H:%M:%S.%f')
        return event_builder.check(
            state=1,
            component='Demo',
            resource='DemoRES',
            output= datetoday,
            perf_data_array=([
                {'metric': 'rta1', 'value': rand1, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' },
                {'metric': 'rta2', 'value': rand2, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' },
                {'metric': 'rta3', 'value': rand3, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' }
            ]),
            **kwargs
        )

    def el4(self, **kwargs):
        rand4 = random.randint(200,400)
        rand5 = random.randint(600,1000)
        rand6 = random.randint(0,100)
        rand7 = random.randint(1,10)
        return event_builder.check(
            state=1,
            component='Demo',
            resource='DemoRES4',
            perf_data_array=([
               {'metric': 'commandes', 'value': rand4, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' },
               {'metric': 'users', 'value': rand5, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' },
               {'metric': 'tauxtransfo', 'value': rand6, 'unit': '%', 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' },
               {'metric': 'nouveauxclients', 'value': rand7, 'unit': None, 'min': None, 'max': None, 'warn': None, 'crit': None, 'type': 'GAUGE' }
            ]),
            output=('Minor : nombre de commandes en baisse'),
            **kwargs
        )

    def el5(self, **kwargs):
        return event_builder.check(
            state=3,
            component='Demo',
            resource='DemoRES5',
            output=('Critical : Service indisponible'),
            **kwargs
        )

    def el6(self, **kwargs):
        return event_builder.check(
            state=2,
            component='Demo',
            resource='DemoRES6',
            **kwargs
        )

    def el7(self, **kwargs):
        return event_builder.check(
            state=3,
            component='Demo',
            resource='DemoRES7',
            **kwargs
        )

    def get_steps(self, **kwargs):

        l1 = ('event l1', self.el1(**kwargs))
        l2 = ('event l2', self.el2(**kwargs))
        l3 = ('event l3', self.el3(**kwargs))
        l4 = ('event l4', self.el4(**kwargs))
        l5 = ('event l5', self.el5(**kwargs))
        l6 = ('event l6', self.el6(**kwargs))
        l7 = ('event l7', self.el7(**kwargs))

        scenario = [l1, l2, l3, l4, l5, l6, l7]
        #for i in xrange(10):
        #    EVTOK = ('event OK', self.el3(**kwargs))
        #    scenario.append(EVTOK)

        return scenario

def get_scenario(**kwargs):
    demoprovisionning = DemoProvisionning()
    return demoprovisionning.get_steps(**kwargs)


def get_name():
    return 'demoprovisionning'


    def get_steps(self, **kwargs):
        return scenario

