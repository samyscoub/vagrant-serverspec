# CANOPSIS LXC Provisionning


:warning: You must have at least 10GB of free space into your LXC datapath

:info: You can change the default LXC path dir into `/etc/lxc/lxc.conf` file ( to create if not exists ) with :

```
lxc.lxcpath = <your_directory_with_more_free_space>
```

